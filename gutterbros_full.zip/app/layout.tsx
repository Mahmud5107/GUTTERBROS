export const metadata = { title: "GutterBros | Gutter Cleaning in Powell & Columbus, OH", description: "Fast, clean, and affordable gutter care. Call 614-588-5365." };

export default function RootLayout({ children }: { children: React.ReactNode }) { return (<html lang="en"><body>{children}</body></html>); }